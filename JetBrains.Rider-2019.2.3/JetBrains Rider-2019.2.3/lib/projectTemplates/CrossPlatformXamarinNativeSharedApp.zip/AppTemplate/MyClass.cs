﻿using System;
namespace AppTemplate
{
    public class MyClass
    {
        public MyClass()
        {
        }
    }
}
