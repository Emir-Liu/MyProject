﻿Public Class Class1
'caret'
End Class