﻿namespace CSharpSharedProjectTemplate
{
  class Class1
  {/*caret*/
  }
}