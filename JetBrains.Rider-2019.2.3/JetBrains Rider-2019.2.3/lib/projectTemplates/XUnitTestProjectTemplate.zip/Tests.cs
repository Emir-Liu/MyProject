﻿using System;
using Xunit;

namespace XUnitTestProjectTemplate
{
  public class Tests
  {
    [Fact]
    public void Test1()
    {
      /*caret*/Assert.True(true);
    }
  }
}