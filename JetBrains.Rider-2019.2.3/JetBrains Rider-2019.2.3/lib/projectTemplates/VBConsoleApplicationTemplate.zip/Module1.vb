﻿Module Module1
  Sub Main()
    'caret'
  End Sub
End Module
