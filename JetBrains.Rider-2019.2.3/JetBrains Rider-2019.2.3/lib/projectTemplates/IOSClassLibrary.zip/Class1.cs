﻿namespace IOSClassLibrary
{
  public class Class1
  {/*caret*/
  }
}