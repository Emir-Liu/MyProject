﻿using System;
using NUnit.Framework;

namespace NUnitTestProjectTemplate
{
  [TestFixture]
  public class Tests
  {
    [Test]
    public void Test1()
    {
      /*caret*/Assert.True(true);
    }
  }
}