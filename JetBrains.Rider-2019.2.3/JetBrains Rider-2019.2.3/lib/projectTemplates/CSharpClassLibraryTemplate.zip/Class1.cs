﻿namespace CSharpClassLibraryTemplate
{
  public class Class1
  {/*caret*/
  }
}