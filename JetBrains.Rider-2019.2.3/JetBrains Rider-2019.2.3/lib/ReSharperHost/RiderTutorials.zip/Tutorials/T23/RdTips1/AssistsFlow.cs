using System.Text;

namespace RdTips1
{
    public static class StringUtils
    {
        public static string AppendNewLine(StringBuilder myStringBuilder)
        {
            myStringBuilder
        }
    }
}