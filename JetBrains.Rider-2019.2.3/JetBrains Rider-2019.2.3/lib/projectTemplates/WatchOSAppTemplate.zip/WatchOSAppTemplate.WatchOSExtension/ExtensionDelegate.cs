﻿using System;
using Foundation;
using WatchKit;

namespace WatchOSAppTemplate.WatchOSExtension
{
  public class ExtensionDelegate : WKExtensionDelegate
  {
    public ExtensionDelegate()
    {/*caret*/
    }
  }
}