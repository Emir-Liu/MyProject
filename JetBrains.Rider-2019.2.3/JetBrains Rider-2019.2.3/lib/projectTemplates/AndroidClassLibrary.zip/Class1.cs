namespace AndroidClassLibrary
{
  public class Class1
  {/*caret*/
  }
}