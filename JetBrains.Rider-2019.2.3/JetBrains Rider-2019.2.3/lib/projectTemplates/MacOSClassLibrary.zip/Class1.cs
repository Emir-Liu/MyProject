﻿namespace MacOSClassLibrary
{
  public class Class1
  {
    public Class1()
    {/*caret*/
    }
  }
}